import React from 'react';
import { Instagram, Mail } from 'lucide-react';

const Home = () => {
  const scrollToServices = () => {
    const servicesSection = document.getElementById('services');
    servicesSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="relative min-h-screen">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80")',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/70 to-black/80"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 flex items-center justify-center min-h-screen py-20">
        <div className="max-w-4xl mx-auto text-white text-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent leading-tight">
            Transform Your Career Journey
          </h1>
          <h2 className="text-xl sm:text-2xl md:text-3xl mb-6 sm:mb-8 text-gray-200 font-light">
            Master In-Demand Skills with Industry Experts
          </h2>
          <p className="text-lg sm:text-xl md:text-2xl mb-8 sm:mb-10 text-gray-300 max-w-3xl mx-auto">
            Join a community of ambitious professionals and get hands-on experience through real projects, expert mentorship, and premium internship opportunities.
          </p>
          <div className="flex flex-wrap justify-center gap-4 sm:gap-6 mb-8 sm:mb-12">
            <button 
              onClick={scrollToServices}
              className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-600 hover:from-blue-600 hover:via-purple-600 hover:to-pink-700 text-white px-6 sm:px-10 py-3 sm:py-4 rounded-lg font-semibold transition-all transform hover:scale-105 text-base sm:text-lg w-full sm:w-auto"
            >
              Start Your Journey
            </button>
          </div>

          {/* Social Links */}
          <div className="flex flex-wrap justify-center gap-4 sm:gap-6">
            <a 
              href="mailto:skillsageofficial@gmail.com"
              className="flex items-center gap-2 sm:gap-3 bg-white/10 hover:bg-white/20 transition-all px-4 sm:px-6 py-2 sm:py-3 rounded-lg border border-white/10 group text-sm sm:text-base w-full sm:w-auto justify-center"
            >
              <Mail className="w-4 h-4 sm:w-5 sm:h-5 text-blue-300 group-hover:scale-110 transition-transform" />
              <span>skillsageofficial@gmail.com</span>
            </a>
            <a 
              href="https://instagram.com/skill_sage_official"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 sm:gap-3 bg-white/10 hover:bg-white/20 transition-all px-4 sm:px-6 py-2 sm:py-3 rounded-lg border border-white/10 group text-sm sm:text-base w-full sm:w-auto justify-center"
            >
              <Instagram className="w-4 h-4 sm:w-5 sm:h-5 text-pink-300 group-hover:scale-110 transition-transform" />
              <span>@skill_sage_official</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Home;