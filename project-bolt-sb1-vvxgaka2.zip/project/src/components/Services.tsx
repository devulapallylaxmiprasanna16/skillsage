import React, { useState } from 'react';
import { 
  Briefcase, 
  Users, 
  ShoppingBag, 
  Play, 
  Code, 
  Presentation,
  GraduationCap,
  Phone,
  AlignCenterVertical as Certificate,
  Users2,
  ArrowRight,
  X,
  FileText,
  Linkedin,
  PenTool,
  Github,
  Rocket,
  Bot,
  Palette
} from 'lucide-react';

const Modal = ({ isOpen, onClose, children }: { isOpen: boolean; onClose: () => void; children: React.ReactNode }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 md:p-6">
      <div className="bg-gray-800 rounded-xl w-full max-w-2xl max-h-[90vh] md:max-h-[80vh] overflow-y-auto">
        <div className="p-4 sm:p-6">
          <button
            onClick={onClose}
            className="float-right p-2 hover:bg-gray-700 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 sm:w-6 sm:h-6 text-gray-400" />
          </button>
          <div className="clear-both">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};

const TrainingCard = ({ 
  icon: Icon, 
  title, 
  price, 
  features 
}: {
  icon: React.ElementType;
  title: string;
  price: string;
  features: string[];
}) => (
  <div className="bg-gray-700/50 rounded-lg p-4 sm:p-6 hover:bg-gray-700/70 transition-colors">
    <div className="flex flex-col sm:flex-row items-start gap-4">
      <div className="p-3 bg-blue-500/20 rounded-lg">
        <Icon className="w-5 h-5 sm:w-6 sm:h-6 text-blue-400" />
      </div>
      <div className="flex-1">
        <h3 className="text-lg sm:text-xl font-semibold text-white mb-2">{title}</h3>
        <p className="text-blue-400 font-semibold mb-4">{price}</p>
        <ul className="space-y-2 text-sm sm:text-base">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start gap-2">
              <span className="text-blue-400 mt-1">•</span>
              <span>{feature}</span>
            </li>
          ))}
        </ul>
        <a
          href="https://forms.gle/LXP2hm7BLALtnLy4A"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 mt-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all text-sm sm:text-base"
        >
          Register Now
          <ArrowRight className="w-4 h-4" />
        </a>
      </div>
    </div>
  </div>
);

const ServiceCard = ({ 
  icon: Icon, 
  title, 
  description, 
  features,
  contactNumber,
  modalContent
}: {
  icon: React.ElementType;
  title: string;
  description: string;
  features?: string[];
  contactNumber?: string;
  modalContent?: React.ReactNode;
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 sm:p-6 border border-white/10 hover:border-white/20 transition-all group">
        <div className="mb-4 inline-block p-3 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-lg group-hover:scale-110 transition-transform">
          <Icon className="w-6 h-6 sm:w-8 sm:h-8 text-blue-400 group-hover:text-purple-400 transition-colors" />
        </div>
        <h3 className="text-lg sm:text-xl font-bold mb-3 text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-blue-400 group-hover:to-purple-500 group-hover:bg-clip-text transition-all">
          {title}
        </h3>
        <p className="text-gray-400 mb-4 text-sm sm:text-base">
          {description}
        </p>
        {features && (
          <ul className="space-y-2 mb-4 text-sm sm:text-base">
            {features.map((feature, index) => (
              <li key={index} className="flex items-start gap-2 text-gray-300">
                <span className="text-blue-400 mt-1">•</span>
                {feature}
              </li>
            ))}
          </ul>
        )}
        <div className="flex flex-wrap gap-4">
          {modalContent && (
            <button 
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-2 text-blue-400 hover:text-purple-400 transition-colors group-hover:gap-3 text-sm sm:text-base"
            >
              Learn More
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
          {contactNumber && (
            <a 
              href={`tel:${contactNumber}`}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-purple-600 transition-all text-sm sm:text-base"
            >
              <Phone className="w-4 h-4" />
              Contact Us
            </a>
          )}
        </div>
      </div>
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        {modalContent}
      </Modal>
    </>
  );
};

const Services = () => {
  const services = [
    {
      icon: Briefcase,
      title: "Digital Marketing",
      description: "Launch your digital marketing career with hands-on experience and monthly stipend.",
      contactNumber: "9704480114",
      modalContent: (
        <div className="text-gray-300 space-y-4">
          <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">Digital Marketing Internship Program</h3>
          <p className="text-sm sm:text-base">Join our comprehensive digital marketing internship program and gain real-world experience while earning. This program includes:</p>
          <ul className="list-disc pl-6 space-y-2 text-sm sm:text-base">
            <li>Monthly stipend of ₹2,500/-</li>
            <li>Hands-on experience in social media management</li>
            <li>Content creation and marketing strategy development</li>
            <li>SEO and digital advertising fundamentals</li>
            <li>Analytics and performance tracking</li>
            <li>Training session coordination (10 people minimum)</li>
            <li>Interview process for selection</li>
            <li>Certificate upon completion</li>
            <li>Complimentary education OTT subscription</li>
          </ul>
          <p className="mt-4 font-semibold text-blue-400 text-sm sm:text-base">Ready to start your digital marketing career? Contact us now!</p>
        </div>
      )
    },
    {
      icon: Users,
      title: "HR Management",
      description: "Develop essential HR skills through practical experience in talent management.",
      contactNumber: "9704480114",
      modalContent: (
        <div className="text-gray-300 space-y-4">
          <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">HR Management Program</h3>
          <p className="text-sm sm:text-base">Gain practical HR experience and develop essential management skills. Our HR program includes:</p>
          <ul className="list-disc pl-6 space-y-2 text-sm sm:text-base">
            <li>Conduct interviews for Digital Marketing interns</li>
            <li>Organize and lead training sessions</li>
            <li>Provide certification for completed trainings</li>
            <li>Develop training materials and curricula</li>
            <li>Monitor intern performance and progress</li>
            <li>Hands-on experience in talent management</li>
            <li>Professional HR certification opportunity</li>
          </ul>
          <p className="mt-4 font-semibold text-blue-400 text-sm sm:text-base">Start your HR career journey with us!</p>
        </div>
      )
    },
    {
      icon: ShoppingBag,
      title: "Reselling Business",
      description: "Start your own business with zero investment through our reselling program.",
      contactNumber: "9704480114",
      modalContent: (
        <div className="text-gray-300 space-y-4">
          <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">Reselling Business Program</h3>
          <p className="text-sm sm:text-base">Launch your reselling business with zero investment! Our program provides:</p>
          <ul className="list-disc pl-6 space-y-2 text-sm sm:text-base">
            <li>Zero initial investment required</li>
            <li>Access to verified wholesale suppliers</li>
            <li>Product selection and pricing strategies</li>
            <li>Marketing and customer acquisition techniques</li>
            <li>Inventory and order management training</li>
            <li>Business scaling guidance</li>
            <li>Customer service best practices</li>
          </ul>
          <p className="mt-4 font-semibold text-blue-400 text-sm sm:text-base">Begin your entrepreneurial journey today!</p>
        </div>
      )
    },
    {
      icon: Code,
      title: "Mini Projects",
      description: "Build your portfolio with practical, industry-relevant projects.",
      contactNumber: "9704480114",
      modalContent: (
        <div className="text-gray-300 space-y-4">
          <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">Mini Projects Program</h3>
          <p className="text-sm sm:text-base">Build your portfolio with hands-on mini projects. Our program includes:</p>
          <ul className="list-disc pl-6 space-y-2 text-sm sm:text-base">
            <li>Practical, industry-relevant projects</li>
            <li>Expert guidance and mentorship</li>
            <li>Portfolio-ready deliverables</li>
            <li>Special student discounts</li>
            <li>Certificate of completion</li>
            <li>Technical support throughout</li>
            <li>Flexible project timelines</li>
          </ul>
          <p className="mt-4 font-semibold text-blue-400 text-sm sm:text-base">Start building your project portfolio today!</p>
        </div>
      )
    },
    {
      icon: Presentation,
      title: "Major Projects",
      description: "Take on complex projects with expert guidance and certification.",
      contactNumber: "9704480114",
      modalContent: (
        <div className="text-gray-300 space-y-4">
          <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">Major Projects Program</h3>
          <p className="text-sm sm:text-base">Take on challenging projects and develop comprehensive solutions. Our program offers:</p>
          <ul className="list-disc pl-6 space-y-2 text-sm sm:text-base">
            <li>End-to-end project management</li>
            <li>Industry expert mentorship</li>
            <li>Advanced technical guidance</li>
            <li>Regular progress reviews</li>
            <li>Professional certification</li>
            <li>Portfolio development</li>
            <li>Career guidance support</li>
          </ul>
          <p className="mt-4 font-semibold text-blue-400 text-sm sm:text-base">Ready to tackle real-world challenges? Join now!</p>
        </div>
      )
    },
    {
      icon: GraduationCap,
      title: "Training Sessions",
      description: "Enhance your skills with our specialized training programs.",
      modalContent: (
        <div className="text-gray-300 space-y-6 sm:space-y-8">
          <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">Available Training Programs</h3>
          <TrainingCard
            icon={Palette}
            title="Canva Design Mastery"
            price="₹499/-"
            features={[
              "1-hour power-packed class",
              "Training completion certificate",
              "Free Canva Pro access",
              "Hands-on design practice",
              "Professional design techniques",
              "Project-based learning"
            ]}
          />
          <TrainingCard
            icon={FileText}
            title="Resume Building Session"
            price="₹199/-"
            features={[
              "Professional resume preparation",
              "Increase your hiring chances",
              "Certificate of completion",
              "1-hour power-packed session"
            ]}
          />
          <TrainingCard
            icon={Linkedin}
            title="LinkedIn Mastery Training"
            price="₹99/-"
            features={[
              "Learn networking strategies",
              "Build meaningful connections",
              "Enhance career opportunities",
              "Training completion certificate"
            ]}
          />
          <TrainingCard
            icon={PenTool}
            title="Content Writing Mastery"
            price="₹199/-"
            features={[
              "1-hour power-packed class",
              "Practical writing exercises",
              "Content strategy basics",
              "Training completion certificate"
            ]}
          />
          <TrainingCard
            icon={Github}
            title="Git & GitHub Training"
            price="₹199/-"
            features={[
              "Master GitHub features",
              "Best practices in version control",
              "Hands-on exercises",
              "Training completion certificate"
            ]}
          />
          <TrainingCard
            icon={Rocket}
            title="Career Building Techniques"
            price="₹499/-"
            features={[
              "1-hour power-packed class",
              "Professional resume crafting",
              "Group discount for 5+",
              "Free Netflix account",
              "Certificate of completion"
            ]}
          />
          <TrainingCard
            icon={Bot}
            title="AI Tools Session"
            price="₹99/-"
            features={[
              "Practical AI tools knowledge",
              "1-hour power-packed session",
              "Hands-on practice",
              "Certificate of completion"
            ]}
          />
        </div>
      )
    }
  ];

  return (
    <section id="services" className="min-h-screen bg-gradient-to-b from-gray-800 to-gray-900 py-16 sm:py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-6 bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            Our Services
          </h2>
          <p className="text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto">
            Comprehensive training programs and services designed to accelerate your professional growth
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-7xl mx-auto">
          {services.map((service) => (
            <ServiceCard
              key={service.title}
              icon={service.icon}
              title={service.title}
              description={service.description}
              features={service.features}
              contactNumber={service.contactNumber}
              modalContent={service.modalContent}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;