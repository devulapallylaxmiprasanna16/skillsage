import React from 'react';
import { Instagram, Mail, Linkedin, Phone } from 'lucide-react';

const About = () => {
  return (
    <section id="about-us" className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white py-16 sm:py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-center mb-10 sm:mb-16 bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
          Meet Our Founders
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8 sm:gap-12 max-w-5xl mx-auto">
          {/* Laxmi Prasanna */}
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 sm:p-8 border border-white/10 hover:border-white/20 transition-all group">
            <div className="relative mb-6 w-48 h-48 sm:w-64 sm:h-64 mx-auto overflow-hidden rounded-xl">
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=800"
                alt="Devulapally Laxmi Prasanna"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <h3 className="text-xl sm:text-2xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Devulapally Laxmi Prasanna
            </h3>
            <h4 className="text-base sm:text-lg text-gray-300 mb-4">Founder & DTrainer at Skillsage</h4>
            <p className="text-gray-400 mb-6 text-sm sm:text-base">
              I specialize in training digital marketing interns, HR interns, and conducting professional development sessions. Let's connect and grow together!
            </p>
            
            <div className="space-y-3">
              <a href="https://wa.me/919704480114" target="_blank" rel="noopener noreferrer" 
                className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                <Phone className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />
                <span>+91 9704480114</span>
              </a>
              <a href="https://www.linkedin.com/in/laxmi-prasanna-5169a42a2" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                <Linkedin className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
                <span>Connect on LinkedIn</span>
              </a>
              <a href="https://www.instagram.com/laxmiprasanna_devulapally" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                <Instagram className="w-4 h-4 sm:w-5 sm:h-5 text-pink-400" />
                <span>@laxmiprasanna_devulapally</span>
              </a>
              <a href="mailto:laxmiprasanna229@gmail.com"
                className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                <Mail className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
                <span>laxmiprasanna229@gmail.com</span>
              </a>
            </div>
          </div>

          {/* Amarakonda Suresh */}
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 sm:p-8 border border-white/10 hover:border-white/20 transition-all group">
            <div className="relative mb-6 w-32 h-32 sm:w-40 sm:h-40 mx-auto overflow-hidden rounded-xl">
              <img
                src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80"
                alt="Amarakonda Suresh"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <h3 className="text-xl sm:text-2xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Amarakonda Suresh
            </h3>
            <h4 className="text-base sm:text-lg text-gray-300 mb-4">Founder & Reselling Trainer</h4>
            <p className="text-gray-400 mb-6 text-sm sm:text-base">
              Expert in reselling strategies and business development. Passionate about empowering entrepreneurs and creating successful business models.
            </p>
            
            <div className="space-y-3">
              <a href="https://wa.me/917377365439" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                <Phone className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />
                <span>+91 7377365439</span>
              </a>
              <a href="https://www.instagram.com/suresh_suri5" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                <Instagram className="w-4 h-4 sm:w-5 sm:h-5 text-pink-400" />
                <span>@suresh_suri5</span>
              </a>
              <a href="mailto:suresh@gmail.com"
                className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors text-sm sm:text-base">
                <Mail className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
                <span>suresh@gmail.com</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;